<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto mt-6">
    <h2 class="text-2xl font-bold text-gray-800 mb-6">📊 สรุป FTE รายบุคคล</h2>

    <!-- 🎚 Filter ปี -->
    <form method="GET" action="<?php echo e(route('fte.index')); ?>" class="mb-6 flex gap-4 items-center">
        <label for="year" class="text-gray-700">ปีงบประมาณ:</label>
        <select name="year" id="year" class="p-2 border rounded">
            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($year); ?>" <?php echo e(request('year') == $year ? 'selected' : ''); ?>>
                    <?php echo e($year); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">🔍 ค้นหา</button>
    </form>

    <!-- 📊 FTE Summary Table -->
    <div class="bg-white shadow rounded-lg overflow-hidden border border-gray-200">
        <table class="w-full table-auto text-sm">
            <thead class="bg-gray-100 text-gray-700">
                <tr>
                    <th class="px-4 py-3 text-left">รายการ</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $fteSummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <?php
                        $rowId = 'row-' . md5($row->name . $loop->index);
                    ?>
                    <tr class="border-t hover:bg-gray-50 cursor-pointer" onclick="toggleDetails('<?php echo e($rowId); ?>')">
                        <td class="px-4 py-2 font-medium text-blue-700">
                            <?php echo e($row->name); ?> 
                        </td>
                    </tr>
                    <tr id="detail-<?php echo e($rowId); ?>" class="hidden bg-gray-50 border-t">
                        <td class="px-4 py-3">
                            <?php if(isset($monthlyFTE[$row->name])): ?>
                                <?php $__currentLoopData = $monthlyFTE[$row->name]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $month => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $carbon = \Carbon\Carbon::parse($month . '-01');
                                        $thaiYear = $carbon->year + 543;
                                        $thaiMonth = $carbon->locale('th')->translatedFormat('F');
                                    ?>
                                    <div class="mb-4">
                                        <h4 class="text-gray-700 font-semibold mb-1">📅 เดือน <?php echo e($thaiMonth); ?> <?php echo e($thaiYear); ?></h4>
                                        <table class="w-full text-sm border border-gray-200 mb-2 table-fixed">
                                            <thead class="bg-gray-100">
                                                <tr>
                                                    <th class="p-2 text-left w-1/3">ชื่อโปรเจค</th>
                                                    <th class="p-2 text-left w-1/4">กลุ่ม</th>
                                                    <th class="p-2 text-left w-1/3">ภาระงาน</th>
                                                    <th class="p-2 text-right w-1/6">FTE</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $sum = 0; ?>
                                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td class="p-2 text-left">
                                                            <a href="<?php echo e(route('projects.show', $item->project->id)); ?>"
                                                               class="text-blue-600 hover:underline">
                                                                <?php echo e($item->project->project_name_th ?? '-'); ?>

                                                            </a>
                                                        </td>
                                                        <td class="p-2 text-left"><?php echo e($item->role_group ?? '-'); ?></td>
                                                        <td class="p-2 text-left"><?php echo e($item->job_detail ?? '-'); ?></td>
                                                        <td class="p-2 text-right"><?php echo e(number_format($item->fte_value, 2)); ?></td>
                                                    </tr>
                                                    <?php $sum += $item->fte_value; ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="bg-gray-200 font-bold">
                                                    <td colspan="3" class="p-2 text-right">รวม</td>
                                                    <td class="p-2 text-right"><?php echo e(number_format($sum, 2)); ?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <p class="text-gray-500">ไม่มีข้อมูล FTE สำหรับบุคคลนี้</p>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td class="p-6 text-center text-gray-400">ไม่พบข้อมูล</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- 🔽 Toggle ลิ้นชัก -->
<script>
function toggleDetails(id) {
    const row = document.getElementById('detail-' + id);
    row.classList.toggle('hidden');
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/maprang/Desktop/SIHPWORK/website/research-system/resources/views/fte/index.blade.php ENDPATH**/ ?>