<?php if($errors->any()): ?>
    <div class="bg-red-100 text-red-800 p-3 rounded mb-4">
        <ul class="list-disc list-inside text-sm">
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>


<?php $__env->startSection('content'); ?>
    <!-- Flatpickr -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/flatpickr.min.css">
    <script src="https://cdn.jsdelivr.net/npm/flatpickr"></script>
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/l10n/th.js"></script>
    <!-- Select2 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />


    <!-- ✅ เพิ่ม Plugin สำหรับเลือกปี -->
    <script src="https://cdn.jsdelivr.net/npm/flatpickr/dist/plugins/monthSelect/index.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/flatpickr/dist/plugins/monthSelect/style.css">

    <div class="max-w-5xl mx-auto mt-6 bg-white shadow-md rounded p-6">
        <h2 class="text-xl font-bold mb-6 text-gray-800">📋 เพิ่มข้อมูลโครงการวิจัย</h2>

        <?php if(session('success')): ?>
            <div class="mb-4 p-3 bg-green-100 text-green-700 rounded">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('projects.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <hr class="my-6 border-t-2 border-gray-300">
            <!-- A: Project Overview -->
            <h3 class="font-semibold text-lg text-blue-700 mb-2">A: ข้อมูลโครงการ</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">ชื่อโครงการ (ภาษาไทย)*</span>
                    <input name="project_name_th" type="text" required class="w-full border p-2 rounded">
                </label>
                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">ชื่อโครงการ (English)</span>
                    <input name="project_name_en" type="text" class="w-full border p-2 rounded">
                </label>
                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">ประเภทของโครงการ*</span>
                    <select name="project_type" id="project_type" class="w-full border p-2 rounded" required>
                        <option value="" disabled selected>เลือกประเภทของโครงการ</option> <!-- สำหรับ placeholder -->
                        <option value="01 ผู้สูงอายุ ตามยุทธศาสตร์ศาสตร์สุขอายุของคณะแพทยศาสตร์ศิริราชพยาบาล">01 ผู้สูงอายุ
                            ตามยุทธศาสตร์ศาสตร์สุขอายุของคณะแพทยศาสตร์ศิริราชพยาบาล</option>
                        <option
                            value="02 โครงการพัฒนาระบบเพื่อการสร้างเสริมสุขภาพสำหรับพระสงฆ์ โดยทีมสหวิทยาการ และการมีส่วนร่วมของประชาชนอย่างยั่งยืน : บางกอกน้อยโมเดล">
                            02 โครงการพัฒนาระบบเพื่อการสร้างเสริมสุขภาพสำหรับพระสงฆ์ โดยทีมสหวิทยาการ
                            และการมีส่วนร่วมของประชาชนอย่างยั่งยืน : บางกอกน้อยโมเดล</option>
                        <option value="03 Health System research and HTA">03 Health System research and HTA</option>
                        <option value="04 การใช้ยาอย่างสมเหตุผล (RDU)">04 การใช้ยาอย่างสมเหตุผล (RDU)</option>
                        <option
                            value="05 Health Policy Platform: Prince Mahidol Award Conference (PMAC), Global Health, UHC">05
                            Health Policy Platform: Prince Mahidol Award Conference (PMAC), Global Health, UHC</option>
                        <option value="06 Real-world Evidence: E-Health, Health Information system, Digital Health">06
                            Real-world Evidence: E-Health, Health Information system, Digital Health</option>
                        <option value="07 Fall prevention + Hip facture preject (VBHC & Registry)">07 Fall prevention + Hip
                            facture preject (VBHC & Registry)</option>
                        <option value="08 การพัฒนาศักยภาพบุคลากร และการจัดเก็บองค์ความรู้เพื่อส่งเสริมการเรียนรู้">08
                            การพัฒนาศักยภาพบุคลากร และการจัดเก็บองค์ความรู้เพื่อส่งเสริมการเรียนรู้</option>
                        <option value="09 SIHP Process Improvement (System Support)">09 SIHP Process Improvement (System
                            Support)</option>
                        <option value="10 อื่นๆ ที่ได้รับมอบหมาย ไม่มีค่า FTE">10 อื่นๆ ที่ได้รับมอบหมาย ไม่มีค่า FTE
                        </option>
                        <option value="11 SIPG">11 SIPG</option>
                        <option value="12 RDMU">12 RDMU</option>
                    </select>
                </label>

                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">กลุ่มเนื้อหา (Theme)*</span>
                    <select name="theme" required class="w-full border p-2 rounded">
                        <option value="" disabled selected>กรุณาเลือกกลุ่มเนื้อหา</option>
                        <option value="T101_Research_วิจัยที่ Health Policy เป็น ผู้วิจัยหลัก">T101_Research_วิจัยที่ Health
                            Policy เป็น ผู้วิจัยหลัก</option>
                        <option value="T102_Research: โครงการวิจัยที่ Team Health Policy เป็น ผู้ร่วมวิจัย">T102_Research:
                            โครงการวิจัยที่ Team Health Policy เป็น ผู้ร่วมวิจัย</option>
                        <option
                            value="T103_Research: โครงการวิจัยที่เป็นไปในลักษณะ Individual Expertise contribution (Skill รายบุคคล) เช่น การเข้าร่วมเขียน paper">
                            T103_Research: โครงการวิจัยที่เป็นไปในลักษณะ Individual Expertise contribution (Skill รายบุคคล)
                            เช่น การเข้าร่วมเขียน paper</option>
                        <option value="T301_Model of Care development (Clinic)">T301_Model of Care development (Clinic)
                        </option>
                        <option value="T401_Cohort Study">T401_Cohort Study</option>
                        <option value="T501_Curriculum Development (Education)">T501_Curriculum Development (Education)
                        </option>
                        <option value="T601_Consult">T601_Consult</option>
                        <option value="T701_Process Improvement (Siriraj Health Policy)">T701_Process Improvement (Siriraj
                            Health Policy)</option>
                        <option value="T801_Conference Session / Knowledge Sharing">T801_Conference Session / Knowledge
                            Sharing</option>
                        <option value="T901_Capacity Building / Skill Development">T901_Capacity Building / Skill
                            Development</option>
                    </select>
                </label>

                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">ลิงก์ Google Drive / Shortcut</span>
                    <input name="shortcut_link" type="text" class="w-full border p-2 rounded">
                </label>
                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">ขนาดโครงการ (S/M/L)</span>
                    <select name="size" required class="w-full border p-2 rounded">
                        <option value="" disabled selected>กรุณาเลือกขนาดของโปรเจค</option>
                        <option value="S">S (ภายนอก / ภายใน / Cohort Study)</option>
                        <option value="M">M (ภายนอก / ภายใน / Cohort Study)</option>
                        <option value="L">L (ภายนอก / ภายใน / Cohort Study)</option>
                        <option value="XL">XL (ภายนอก) </option>
                    </select>
                </label>
                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1"> รหัสโครงการ R</span>
                    <input name="r_code" type="text" placeholder="R:001" class="w-full border p-2 rounded">
                </label>

                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">ปีโปรเจค</span>
                    <select name="start_year" class="w-full border p-2 rounded" required>
                        <option value="" disabled
                            <?php echo e(old('start_year', $project->start_year ?? '') == '' ? 'selected' : ''); ?>>เลือกปีโปรเจค
                        </option>
                        <?php for($year = now()->year + 2 + 543; $year >= 2557; $year--): ?>
                            <option value="<?php echo e($year); ?>"
                                <?php echo e(old('start_year', $project->start_year ?? '') == $year ? 'selected' : ''); ?>>
                                <?php echo e($year); ?>

                            </option>
                        <?php endfor; ?>
                    </select>
                </label>





                <!-- Funding Source Section -->
                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">DA102 - ประเภทแหล่งทุน</span>
                    <select name="funding_type" required class="w-full border p-2 rounded">
                        <option value="" disabled selected>กรุณาเลือกขนาดของโปรเจค</option>
                        <option value="ภายใน">ภายใน</option>
                        <option value="ภายนอก">ภายนอก</option>
                    </select>
                </label>

                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">DA103 - ชื่อแหล่งทุน</span>
                    <input name="funding_source" type="text" class="w-full border p-2 rounded"
                        placeholder="ชื่อหน่วยงานหรือองค์กรที่ให้ทุน">
                </label>


                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">DA104 - รัฐบาล / เอกชน / มูลนิธิ</span>
                    <select name="funding_org_type" required class="w-full border p-2 rounded">
                        <option value="" disabled selected>กรุณาเลือกประเภทองค์กร</option>
                        <option value="รัฐบาล">รัฐบาล</option>
                        <option value="เอกชน">เอกชน</option>
                        <option value="มูลนิธิ">มูลนิธิ</option>
                    </select>
                </label>

                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">DA105 - ชื่อทุน</span>
                    <input name="funding_name" type="text" class="w-full border p-2 rounded"
                        placeholder="ชื่อทุนที่ได้รับ">
                </label>

                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">DA106 - งบประมาณ (บาท)</span>
                    <input id="budgetInput" name="budget" type="text" class="w-full border p-2 rounded"
                        placeholder="ระบุจำนวนเงินที่ได้รับ" inputmode="decimal" pattern="[\d,\.]*">

                </label>

            </div>

            <!-- B: ระยะเวลาดำเนินโครงการ -->
            <h3 class="font-semibold text-lg text-blue-700 mt-6 mb-2">B: ระยะเวลาดำเนินโครงการ</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">

                <label class="w-full relative">
                    <span class="block text-sm text-gray-700 mb-1">วันที่โครงการเริ่มทำงานของทีมวิจัย</span>
                    <input name="team_start_date" type="text"
                        class="thai-datepicker w-full border p-2 rounded pl-10 <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('team_start_date')); ?>" placeholder="กรุณาเลือกวันที่เริ่มงานของทีม">
                    <!-- ปุ่มไอคอนปฏิทิน (absolute ซ้ายใน input) -->
                    <svg class="absolute left-3 top-9 w-5 h-5 text-gray-500 pointer-events-none" fill="none"
                        stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                </label>

                <label class="w-full relative">
                    <span class="block text-sm text-gray-700 mb-1">วันที่สิ้นสุดการทำงานของทีมวิจัย</span>
                    <input name="team_end_date" type="text" class="thai-datepicker w-full border p-2 rounded pl-10"
                        value="<?php echo e(old('team_end_date')); ?>" placeholder="กรุณาเลือกวันที่สิ้นสุดการทำงานของทีม">
                    <!-- ปฏิทินไอคอน -->
                    <svg class="absolute left-3 top-9 w-5 h-5 text-gray-500 pointer-events-none" fill="none"
                        stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                </label>


                <label class="w-full relative">
                    <span class="block text-sm text-gray-700 mb-1">BA001 - วันที่เริ่มเขียน Proposal</span>
                    <input name="proposal_date" type="text"
                        class="thai-datepicker w-full border p-2 rounded pl-10 <?php $__errorArgs = ['proposal_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('proposal_date')); ?>" placeholder="กรุณาเลือกวันที่เริ่มเขียน Proposal">
                    <!-- ไอคอนปฏิทิน -->
                    <svg class="absolute left-3 top-9 w-5 h-5 text-gray-500 pointer-events-none" fill="none"
                        stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                </label>


                <label class="w-full relative">
                    <span class="block text-sm text-gray-700 mb-1">BC101 - วันที่สัญญาอนุมัติ</span>
                    <input name="contract_date" type="text"
                        class="thai-datepicker w-full border p-2 rounded pl-10 <?php $__errorArgs = ['contract_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('contract_date')); ?>" placeholder="กรุณาเลือกวันที่อนุมัติสัญญา">
                    <svg class="absolute left-3 top-9 w-5 h-5 text-gray-500 pointer-events-none" fill="none"
                        stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <?php $__errorArgs = ['contract_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>

                <label class="w-full relative">
                    <span class="block text-sm text-gray-700 mb-1">BC102 - วันที่โครงการเริ่ม (ตามสัญญา)</span>
                    <input name="start_date" type="text"
                        class="thai-datepicker w-full border p-2 rounded pl-10 <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        value="<?php echo e(old('start_date')); ?>" placeholder="กรุณาเลือกวันที่เริ่มตามสัญญา">
                    <svg class="absolute left-3 top-9 w-5 h-5 text-gray-500 pointer-events-none" fill="none"
                        stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                    <?php $__errorArgs = ['start_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>

                <label class="w-full relative ">
                    <span class="block text-sm text-gray-700 mb-1">วันที่สิ้นสุด (ตามสัญญา)</span>
                    <input name="end_date" type="text" class="thai-datepicker w-full border p-2 rounded pl-10"
                        value="<?php echo e(old('end_date')); ?>" placeholder="กรุณาเลือกวันที่สิ้นสุดตามสัญญา">
                    <svg class="absolute left-3 top-9 w-5 h-5 text-gray-500 pointer-events-none" fill="none"
                        stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                </label>




                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">BA000 - Project Planning (Status)</span>
                    <select name="planning_status" id="planning_status"
                        class="w-full border p-2 rounded text-white font-semibold" onchange="updateStatusColor(this)"
                        required>
                        <option value="0" data-color="#991b1b">ยกเลิก (Canceled) 0%</option>
                        <option value="" disabled selected style="background-color: white; ">ระบุคำตอบ
                        </option>
                        <option value="25" data-color="#dc2626">อยู่ระหว่างการรอ (On Hold) 25%</option>
                        <option value="50" data-color="#f59e0b">กำลังดำเนินการ (In Progress) 50%</option>
                        <option value="75" data-color="#3b82f6">อยู่ในระหว่างการตรวจสอบ/พิจารณา (In Review) 75%
                        </option>
                        <option value="100" data-color="#16a34a">เสร็จสิ้น (Complete) 100%</option>

                    </select>
                </label>



                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">BC000 - Project Execution (Status)</span>
                    <select name="execution_status" id="execution_status"
                        class="w-full border p-2 rounded text-white font-semibold" onchange="updateStatusColor(this)"
                        required>
                        <option value="" selected hidden class="text-b">ระบุคำตอบ</option>
                        <option value="0" data-color="#991b1b">ยกเลิก (Canceled) 0%</option>
                        <option value="25" data-color="#dc2626">อยู่ระหว่างการรอ (On Hold) 25%</option>
                        <option value="50" data-color="#f59e0b">กำลังดำเนินการ (In Progress) 50%</option>
                        <option value="75" data-color="#3b82f6">อยู่ในระหว่างการตรวจสอบ/พิจารณา (In Review) 75%
                        </option>
                        <option value="100" data-color="#16a34a">เสร็จสิ้น (Complete) 100%</option>

                    </select>

                    <?php $__errorArgs = ['execution_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>



                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">BD000 - Review Status (Status)</span>
                    <select name="review_status" id="review_status"
                        class="w-full border p-2 rounded text-white font-semibold" onchange="updateStatusColor(this)">
                        <option value="" disabled selected>ระบุคำตอบ</option>
                        <option value="0" data-color="#991b1b" <?php echo e(old('review_status') == '0' ? 'selected' : ''); ?>>
                            ยกเลิก (Canceled) 0%</option>
                        <option value="25" data-color="#dc2626" <?php echo e(old('review_status') == '25' ? 'selected' : ''); ?>>
                            อยู่ระหว่างการรอ (On Hold) 25%</option>
                        <option value="50" data-color="#f59e0b" <?php echo e(old('review_status') == '50' ? 'selected' : ''); ?>>
                            กำลังดำเนินการ (In Progress) 50%</option>
                        <option value="75" data-color="#3b82f6" <?php echo e(old('review_status') == '75' ? 'selected' : ''); ?>>
                            อยู่ในระหว่างการตรวจสอบ/พิจารณา (In Review) 75%</option>
                        <option value="100" data-color="#16a34a"
                            <?php echo e(old('review_status') == '100' ? 'selected' : ''); ?>>เสร็จสิ้น (Complete) 100%</option>

                    </select>

                    <?php $__errorArgs = ['review_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>

                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">BE000 - Closure Status (status)</span>
                    <select name="closure_status" id="closure_status"
                        class="w-full border p-2 rounded text-white font-semibold" onchange="updateStatusColor(this)">
                        <option value="" disabled <?php echo e(old('closure_status') ? '' : 'selected'); ?>>ระบุคำตอบ</option>
                        <option value="25" data-color="#dc2626"
                            <?php echo e(old('closure_status') == '25' ? 'selected' : ''); ?>>อยู่ระหว่างการรอ (On Hold) 25%</option>
                        <option value="50" data-color="#f59e0b"
                            <?php echo e(old('closure_status') == '50' ? 'selected' : ''); ?>>กำลังดำเนินการ (In Progress) 50%</option>
                        <option value="75" data-color="#3b82f6"
                            <?php echo e(old('closure_status') == '75' ? 'selected' : ''); ?>>อยู่ในระหว่างการตรวจสอบ/พิจารณา (In
                            Review) 75%</option>
                        <option value="100" data-color="#16a34a"
                            <?php echo e(old('closure_status') == '100' ? 'selected' : ''); ?>>เสร็จสิ้น (Complete) 100%</option>
                        <option value="0" data-color="#991b1b" <?php echo e(old('closure_status') == '0' ? 'selected' : ''); ?>>
                            ยกเลิก (Canceled) 0%</option>
                    </select>

                    <?php $__errorArgs = ['closure_status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>


            </div>




            <hr class="my-6 border-t-2 border-gray-300">
            <!-- รหัส IRB -->
            <h3 class="font-semibold text-lg text-blue-700 mb-2">รหัส IRB</h3>
            <div id="irb-code-container" class="space-y-2 mb-4">
                <div id="irb-0" class="irb-row grid grid-cols-3 gap-2 items-center">
                    <div class="w-full">
                        <span class="block text-sm text-gray-700 mb-1">รหัส IRB ที่ <span
                                class="irb-index">1</span></span>
                        <input name="irbs[0][code]" type="text" placeholder="EC2025"
                            class="w-full border p-2 rounded">
                    </div>
                    <div class="w-full">
                        <span class="block text-sm text-gray-700 mb-1">จาก (ชื่อหน่วยงาน)</span>
                        <input name="irbs[0][source]" type="text" placeholder="ชื่อหน่วยงาน"
                            class="w-full border p-2 rounded">
                    </div>
                    <div class="w-full flex gap-2 items-end">
                        <div class="w-full relative">
                            <span class="block text-sm text-gray-700 mb-1">วันที่หมดอายุ</span>
                            <input name="irbs[0][exp_date]" type="text" placeholder="เลือกวันที่"
                                class="thai-datepicker w-full border p-2 rounded pl-10" placeholder="โปรดเลือกวันที่">

                            <!-- ไอคอนปฏิทิน -->
                            <svg class="w-5 h-5 absolute top-9 left-3 text-gray-500 pointer-events-none"
                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                        </div>

                        <button type="button" onclick="removeRow('irb-0', 'irb')" class="text-red-600 mb-2">✕</button>
                    </div>
                </div>
            </div>
            <button type="button" onclick="addIRBCode()" class="mb-6 px-3 py-1 bg-red-600 text-white rounded">+
                เพิ่มรหัส IRB</button>



            <hr class="my-6 border-t-2 border-gray-300">
            <!-- C: Roles and Responsibilities -->
            <h3 class="font-semibold text-lg text-blue-700 mb-2">C: Roles and Responsibilities</h3>
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">CA101 - ชื่อ PI (ผู้วิจัยหลัก)</span>
                    <input name="pi_name" type="text" class="w-full border p-2 rounded" value=""
                        placeholder="คำนำหน้า ชื่อ-นามสกุล">
                    <?php $__errorArgs = ['pi_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">CA103 - สังกัดผู้วิจัยหลัก</span>
                    <input name="pi_affiliation" type="text" class="w-full border p-2 rounded" value=""
                        placeholder="สังกัดผู้วิจัยหลัก">
                    <?php $__errorArgs = ['pi_affiliation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="text-sm text-red-500"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </label>
            </div>








            <h3 class="text-balance text-blue-700 mb-2">รายชื่อผู้ร่วมวิจัย (COPI)</h3>
            <div id="copi-container" class="space-y-2 mb-4">
                <div id="copi-0" class="copi-row grid grid-cols-2 gap-4 items-center">
                    <label class="w-full">
                        <span class="block text-sm text-gray-700 mb-1">ชื่อ COPI คนที่ <span
                                class="copi-index">1</span></span>
                        <input name="copis[0][name]" type="text" class="w-full border p-2 rounded"
                            placeholder="คำนำหน้า ชื่อ-นามสกุล">
                    </label>
                    <div class="flex gap-2 w-full">
                        <label class="w-full">
                            <span class="block text-sm text-gray-700 mb-1">สังกัด COPI คนที่ <span
                                    class="copi-index">1</span></span>
                            <input name="copis[0][affiliation]" type="text" class="w-full border p-2 rounded"
                                placeholder="สังกัด COPI">
                        </label>
                        <button type="button" onclick="removeRow('copi-0', 'copi')" class="text-red-600 mt-6">✕</button>
                    </div>
                </div>
            </div>
            <button type="button" onclick="addCopiRow()" class="mb-6 px-3 py-1 bg-yellow-600 text-white rounded">+ เพิ่ม
                COPI</button>
            <h3 class="text-blue-700 font-semibold mb-2">Co-Researcher</h3>
            <div id="coresearch-container" class="space-y-4 mb-4">
                <div id="coresearch-0" class="coresearch-row space-y-2">
                    <!-- บรรทัดที่ 1: ชื่อ -->
                    <label class="block w-full">
                        <span class="block text-sm mb-1">ชื่อ Co-Researcher ที่ <span
                                class="coresearch-index">1</span></span>
                        <input name="coresearch[0][name]" type="text" class="w-full border p-2 rounded"
                            placeholder="ยศ ชื่อ นามสกุล">
                    </label>

                    <!-- บรรทัดที่ 2: สังกัด + ภายใน/ภายนอก + ลบ -->
                    <div class="grid grid-cols-12 gap-4 items-end">
                        <label class="col-span-5">
                            <span class="block text-sm mb-1">สังกัด</span>
                            <input name="coresearch[0][affiliation]" type="text" class="w-full border p-2 rounded"
                                placeholder="สังกัด">
                        </label>

                        <label class="col-span-5">
                            <span class="block text-sm mb-1">คนภายนอก/ภายใน</span>
                            <select name="coresearch[0][unit_status]" required class="w-full border p-2 rounded">
                                <option value="" disabled selected>กรุณาเลือก</option>
                                <option value="ภายใน">ภายใน</option>
                                <option value="ภายนอก">ภายนอก</option>
                            </select>
                        </label>

                        <div class="col-span-2 flex items-center justify-end pt-6">
                            <button type="button" onclick="removeRow('coresearch-0', 'coresearch')"
                                class="text-red-600 text-xl">✕</button>
                        </div>
                    </div>
                </div>
            </div>


            <button type="button" onclick="addCoResearchRow()" class="mb-6 px-3 py-1 bg-purple-600 text-white rounded">+
                เพิ่ม Co-Researcher</button>




            <?php
                $allUsers = \App\Models\User::orderBy('name')->get();
                $roleGroups = ['Scientific', 'Management', 'IT + Communication', 'Logistics + Admin'];
                $jobDetails = [
                    'Researcher',
                    'Researcher Assistant',
                    'Project Manager',
                    'Research Coordinator',
                    'นักวิชาการสารสนเทศ',
                    'นักประชาสัมพันธ์',
                    'เจ้าหน้าที่บริหารงานทั่วไป',
                ];
            ?>

            <hr class="my-6 border-t-2 border-gray-300">
            <h3 class="font-semibold text-lg text-blue-700 mb-2">D: รายชื่อผู้มีส่วนร่วม (FTE)</h3>
            <div id="fte-container" class="space-y-4 mb-4">
                <div id="fte-0" class="fte-row space-y-2">
                    <!-- บรรทัด 1 -->
                    <div class="grid grid-cols-2 gap-4">
                        <label class="w-full">
                            <span class="block text-sm text-gray-700 mb-1">1. ชื่อ-นามสกุล</span>
                            <select name="fte_roles[0][name]" class="w-full border p-2 rounded" required>
                                <option value="" disabled selected>เลือกผู้รับผิดชอบ</option>
                                <?php $__currentLoopData = $allUsers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $fullName = trim($user->prefix . ' ' . $user->name); ?>
                                    <option value="<?php echo e($fullName); ?>"><?php echo e($fullName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                        <label class="w-full">
                            <span class="block text-sm text-gray-700 mb-1">กลุ่ม</span>
                            <select name="fte_roles[0][role_group]" class="w-full border p-2 rounded">
                                <option value="" disabled selected>เลือกกลุ่ม</option>
                                <?php $__currentLoopData = $roleGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($group); ?>"><?php echo e($group); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                    </div>

                    <!-- บรรทัด 2 -->
                    <div class="grid grid-cols-3 gap-4">
                        <label class="w-full">
                            <span class="block text-sm text-gray-700 mb-1">ภาระงาน</span>
                            <select name="fte_roles[0][job_detail]" class="w-full border p-2 rounded">
                                <option value="" disabled selected>เลือกภาระงาน</option>
                                <?php $__currentLoopData = $jobDetails; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($job); ?>"><?php echo e($job); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                        <label class="w-full relative">
                            <span class="block text-sm text-gray-700 mb-1">วันเริ่มต้นภาระงาน</span>
                            <input name="fte_roles[0][start_date]" type="text " placeholder="โปรดใส่วันที่"
                                class="thai-datepicker w-full border p-2 rounded pl-10" required>
                            <svg class="w-5 h-5 absolute top-9 left-3 text-gray-500 pointer-events-none"
                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                        </label>
                        <label class="w-full relative">
                            <span class="block text-sm text-gray-700 mb-1">วันสิ้นสุดภาระงาน</span>
                            <input name="fte_roles[0][end_date]" type="text"
                                class="thai-datepicker w-full border p-2 rounded pl-10" placeholder="โปรดใส่วันที่"
                                required>
                            <svg class="w-5 h-5 absolute top-9 left-3 text-gray-500 pointer-events-none"
                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                                stroke="currentColor">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                    d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                            </svg>
                        </label>
                    </div>

                    <!-- บรรทัด 3 -->
                    <div class="flex gap-4 items-end">
                        <label class="w-full">
                            <span class="block text-sm text-gray-700 mb-1">FTE</span>
                            <input name="fte_roles[0][fte_value]" type="number" step="0.01"
                                class="w-full border p-2 rounded" placeholder="โปรดใส่ค่า FTE" required>
                        </label>
                        <button type="button" onclick="removeRow('fte-0', 'fte')" class="text-red-600 mb-2">✕</button>
                    </div>
                </div>
            </div>

            <button type="button" onclick="addFTERow()" class="mb-6 px-3 py-1 bg-blue-600 text-white rounded">+
                เพิ่มผู้มีส่วนร่วม</button>




            <hr class="my-6 border-t-2 border-gray-300">
            <!-- E: ผลงานวิจัย (Output) -->
            <h3 class="font-semibold text-lg text-blue-700 mb-2">E: ผลงานวิจัย (Output)</h3>
            <div id="output-container" class="space-y-4 mb-4">
                <div id="output-0" class="output-row space-y-2">
                    <!-- บรรทัดแรก: ชื่อผลงาน -->
                    <label class="block w-full">
                        <span class="block text-sm text-gray-700 mb-1">ชื่อผลงานที่ <span
                                class="output-index">1</span></span>
                        <input name="outputs[0][title]" type="text" class="w-full border p-2 rounded"
                            placeholder="ชื่อผลงาน">
                    </label>

                    <!-- บรรทัดที่สอง: ประเภท, หมายเหตุ, ปี -->
                    <div class="grid grid-cols-3 gap-4 items-end">
                        <label class="w-full">
                            <span class="block text-sm text-gray-700 mb-1">ประเภทของผลงาน</span>
                            <input name="outputs[0][type]" type="text" class="w-full border p-2 rounded"
                                placeholder="เช่น รายงาน">
                        </label>
                        <label class="w-full">
                            <span class="block text-sm text-gray-700 mb-1">รายละเอียด / หมายเหตุ / LINK</span>
                            <input name="outputs[0][project_output]" type="text" class="w-full border p-2 rounded"
                                placeholder="เพิ่มเติม">
                        </label>
                        <div class="flex gap-2 w-full">
                            <label class="w-full">
                                <span class="block text-sm text-gray-700 mb-1">ปี</span>
                                <input name="outputs[0][year]" type="text" class="w-full border p-2 rounded"
                                    placeholder="2025">
                            </label>
                            <button type="button" onclick="removeRow('output-0', 'output')"
                                class="text-red-600 mb-2">✕</button>
                        </div>
                    </div>
                </div>
            </div>
            <button type="button" onclick="addOutputRow()" class="mb-6 px-3 py-1 bg-green-600 text-white rounded">+
                เพิ่ม Output</button>

            <hr class="my-6 border-t-2 border-gray-300">
            <!-- ยุทธศาสตร์ -->
            <h3 class="font-semibold text-lg text-blue-700 mb-2">ยุทธศาสตร์ Siriraj Health Policy</h3>
            <table class="w-full table-auto text-sm mb-6">
                <thead>
                    <tr class="bg-gray-100">
                        <th class="px-3 py-2 text-left">หมวด</th>
                        <th class="px-3 py-2 text-left">รายการ</th>
                        <th class="px-3 py-2">มี</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                        $strategies = [
                            '1' => [
                                'label' => 'AA501: Capacity Building',
                                'items' => [
                                    '1' => '1.1 การสรรหานักวิจัยด้านนโยบายสุขภาพที่มีความสามารถ',
                                    '2' => '1.2 การพัฒนาศักยภาพฯ ผ่านการเรียนรู้จากการปฏิบัติงานจริง',
                                    '3' => '1.3 การพัฒนาศักยภาพฯ ผ่านการศึกษาต่อเนื่อง',
                                    '4' => '1.4 การบูรณาการกับการเรียนการสอนนักศึกษาแพทย์',
                                    '5' => '1.5 การพัฒนาศักยภาพฯ ให้แก่บุคลากรศิริราช',
                                ],
                            ],
                            '2' => [
                                'label' => 'AA502: Excellence Research',
                                'items' => [
                                    '1' => '2.1 การเพิ่มบทบาทของหน่วยวิจัยฯ',
                                    '2' => '2.2 การสร้างความสัมพันธ์กับผู้กำหนดนโยบาย',
                                    '3' => '2.3 การสรรหาและกำหนดหัวข้อวิจัย',
                                ],
                            ],
                            '3' => [
                                'label' => 'AA503: Health Policy Linkage',
                                'items' => [
                                    '1' => '3.1 การสังเคราะห์องค์ความรู้ฯ จากงานวิจัยต้นแบบ',
                                    '2' => '3.2 การดำเนินงานวิจัยที่มีคุณภาพ',
                                    '3' => '3.3 ผลักดันให้งานวิจัยใช้ตัดสินใจนโยบาย',
                                    '4' => '3.4 เชื่อมโยงนวัตกรรมกับการพัฒนานโยบาย',
                                    '5' => '3.5 การสื่อสารงานวิจัยต่อสาธารณะ',
                                ],
                            ],
                            '4' => [
                                'label' => 'AA504: Partnership Engagement',
                                'items' => [
                                    '1' => '4.1 การสร้างเครือข่ายงานวิจัย',
                                    '2' => '4.2 การสร้างความร่วมมือฯ',
                                ],
                            ],
                            '5' => [
                                'label' => 'AA505: System Support',
                                'items' => [
                                    '1' => '5.1 การพัฒนาระบบสนับสนุนการดำเนินงานวิจัย',
                                    '2' => '5.2 การพัฒนาระบบสนับสนุนเส้นทางอาชีพในหน่วยวิจัย',
                                ],
                            ],
                        ];
                    ?>

                    <?php $__currentLoopData = $strategies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sKey => $strategy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr class="border-t">
                            <td class="px-3 py-2 font-bold" rowspan="<?php echo e(count($strategy['items']) + 1); ?>">
                                <?php echo e($strategy['label']); ?></td>
                        </tr>
                        <?php $__currentLoopData = $strategy['items']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $iKey => $desc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="border-t">
                                <td class="px-3 py-2"><?php echo e($desc); ?></td>
                                <td class="px-3 py-2 text-center">
                                    <input type="checkbox" name="strategy_<?php echo e($sKey); ?>_<?php echo e($iKey); ?>"
                                        class="mr-1">
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>

            <!-- Submit -->
            <div class="mt-6">
                <button type="submit" class="bg-indigo-600 text-white px-6 py-2 rounded hover:bg-indigo-700">💾
                    บันทึกข้อมูล</button>
            </div>
        </form>
    </div>

    <script>
        // ✅ TO BUDDHIST
        function toBuddhist(selectedDates, dateStr, instance) {
            const altInput = instance.altInput;

            if (selectedDates.length > 0 && altInput) {
                const date = selectedDates[0];
                const day = date.getDate();
                const month = date.toLocaleString('th-TH', {
                    month: 'long'
                });
                const year = date.getFullYear() + 543;
                altInput.value = `${day} ${month} ${year}`;
            }

            setTimeout(() => {
                const yearInputs = instance?.calendarContainer?.querySelectorAll(
                    '.flatpickr-current-month input.cur-year') || [];
                yearInputs.forEach(el => {
                    let y = parseInt(el.value);
                    if (y < 2500) el.value = y + 543;

                    el.addEventListener('blur', () => {
                        let y2 = parseInt(el.value);
                        if (y2 > 2400) {
                            el.value = y2 - 543;
                            instance.setDate(new Date(y2 - 543, instance.currentMonth, 1));
                            setTimeout(() => toBuddhist(selectedDates, dateStr, instance), 5);
                        }
                    });
                });
            }, 5);
        }

        function initThaiDatepickers() {
            flatpickr(".thai-datepicker", {
                locale: "th",
                dateFormat: "d-m-Y",
                altInput: true,
                altFormat: "j F Y",
                prevArrow: "",
                nextArrow: "",
                onReady: toBuddhist,
                onClose: toBuddhist,
                onChange: toBuddhist,
                onMonthChange: toBuddhist,
                onYearChange: toBuddhist,
                disableMobile: true
            });
        }

        // ✅ STATUS COLOR
        function updateStatusColor(selectEl) {
            const selected = selectEl.options[selectEl.selectedIndex];
            const bgColor = selected.getAttribute("data-color") || "#ffffff";
            const isPlaceholder = selected.value === "";
            selectEl.style.backgroundColor = bgColor;
            selectEl.style.color = isPlaceholder ? "#9ca3af" : "#ffffff";
        }

        // ✅ FORMAT BUDGET
        function setupBudgetInput() {
            const input = document.getElementById('budgetInput');
            if (!input) return;

            input.addEventListener('input', () => {
                let value = input.value.replace(/,/g, '');
                const parts = value.split('.');
                if (parts.length > 2) value = parts[0] + '.' + parts[1];
                let [intPart, decimalPart] = value.split('.');
                intPart = intPart.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
                input.value = decimalPart !== undefined ? `${intPart}.${decimalPart}` : intPart;
            });

            input.form?.addEventListener('submit', () => {
                input.value = input.value.replace(/,/g, '');
            });
        }

        // ✅ REMOVE & REINDEX
        function removeRow(id, type) {
            const el = document.getElementById(id);
            if (el) el.remove();

            const map = {
                fte: reindexFTE,
                copi: reindexCopi,
                irb: reindexIRB,
                output: reindexOutput,
                coresearch: reindexCoResearch
            };
            map[type]?.();
        }

        function reindexIRB() {
            document.querySelectorAll('#irb-code-container .irb-row').forEach((row, i) => {
                row.querySelector('.irb-index').textContent = i + 1;
            });
        }

        function reindexFTE() {
            document.querySelectorAll('#fte-container .fte-row').forEach((row, i) => {
                row.querySelector('.fte-index').textContent = i + 1;
            });
        }

        function reindexOutput() {
            document.querySelectorAll('#output-container .output-row').forEach((row, i) => {
                row.querySelector('.output-index').textContent = i + 1;
            });
        }

        function reindexCopi() {
            document.querySelectorAll('#copi-container .copi-row').forEach((row, i) => {
                row.querySelectorAll('.copi-index').forEach(span => span.textContent = i + 1);
            });
        }

        function reindexCoResearch() {
            document.querySelectorAll('#coresearch-container .coresearch-row').forEach((row, i) => {
                row.querySelector('.coresearch-index').textContent = i + 1;
            });
        }

        // ✅ ADD ROWS
   let irbIndex = 1;

function addIRBCode() {
    const id = `irb-${irbIndex}`;
    document.getElementById('irb-code-container').insertAdjacentHTML('beforeend', `
        <div id="${id}" class="irb-row grid grid-cols-3 gap-2 items-center">
            <div class="w-full">
                <span class="block text-sm text-gray-700 mb-1">รหัส IRB ที่ <span class="irb-index">${irbIndex + 1}</span></span>
                <input name="irbs[${irbIndex}][code]" type="text" class="w-full border p-2 rounded" placeholder="EC2025">
            </div>
            <div class="w-full">
                <span class="block text-sm text-gray-700 mb-1">จาก (ชื่อหน่วยงาน)</span>
                <input name="irbs[${irbIndex}][source]" type="text" class="w-full border p-2 rounded" placeholder="ชื่อหน่วยงาน">
            </div>
            <div class="w-full flex gap-2 items-end">
                <div class="w-full relative">
                    <span class="block text-sm text-gray-700 mb-1">วันที่หมดอายุ</span>
                    <input name="irbs[${irbIndex}][exp_date]" type="text" class="thai-datepicker w-full border p-2 rounded pl-10" placeholder="เลือกวันที่">
                    <svg class="w-5 h-5 absolute top-9 left-3 text-gray-500 pointer-events-none"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                </div>
                <button type="button" onclick="removeRow('${id}', 'irb')" class="text-red-600 mb-2">✕</button>
            </div>
        </div>
    `);
    irbIndex++;
    reindexIRB();
    initThaiDatepickers(); // สำหรับรีเปิด datepicker ใหม่ที่เพิ่มมา
}

        let fteIndex = 1;

        const userOptions = <?php echo json_encode(
            \App\Models\User::orderBy('name')->get()->map(function ($u) {
                    return [
                        'fullName' => trim($u->prefix . ' ' . $u->name), ];
                }), 512) ?>;

        const roleGroups = ['Scientific', 'Management', 'IT + Communication', 'Logistics + Admin'];
        const jobDetails = [
            'Researcher',
            'Researcher Assistant',
            'Project Manager',
            'Research Coordinator',
            'นักวิชาการสารสนเทศ',
            'นักประชาสัมพันธ์',
            'เจ้าหน้าที่บริหารงานทั่วไป',
        ];

        function addFTERow() {
            const id = `fte-${fteIndex}`;

            const userDropdown = userOptions.map(u =>
                `<option value="${u.fullName}">${u.fullName}</option>`
            ).join('');

            const groupDropdown = roleGroups.map(g =>
                `<option value="${g}">${g}</option>`
            ).join('');

            const jobDropdown = jobDetails.map(j =>
                `<option value="${j}">${j}</option>`
            ).join('');

            document.getElementById('fte-container').insertAdjacentHTML('beforeend', `
        <div id="${id}" class="fte-row space-y-2">
            <div class="grid grid-cols-2 gap-4">
                <label class="w-full">
                    <span class="fte-index block text-sm text-gray-700 mb-1">${fteIndex + 1}. ชื่อ-นามสกุล</span>
                    <select name="fte_roles[${fteIndex}][name]" class="w-full border p-2 rounded" required>
                        <option value="" disabled selected>เลือกผู้รับผิดชอบ</option>
                        ${userDropdown}
                    </select>
                </label>
                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">กลุ่ม</span>
                    <select name="fte_roles[${fteIndex}][role_group]" class="w-full border p-2 rounded">
                        <option value="" disabled selected>โปรดเลือกกลุ่ม</option>
                        ${groupDropdown}
                    </select>
                </label>
            </div>
            <div class="grid grid-cols-3 gap-4">
                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">ภาระงาน</span>
                    <select name="fte_roles[${fteIndex}][job_detail]" class="w-full border p-2 rounded placeholder="โปรดเลือกภาระงาน"">
                        <option value="" disabled selected>เลือกภาระงาน</option>
                        ${jobDropdown}
                    </select>
                </label>
                <label class="w-full relative">
                    <span class="block text-sm text-gray-700 mb-1">วันเริ่ม</span>
                    <input name="fte_roles[${fteIndex}][start_date]" type="text" class="thai-datepicker w-full border p-2 rounded pl-10" placeholder="โปรดใส่วันที่" required>
                    <svg class="w-5 h-5 absolute top-9 left-3 text-gray-500 pointer-events-none"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                </label>
                <label class="w-full relative">
                    <span class="block text-sm text-gray-700 mb-1">วันสิ้นสุด</span>
                    <input name="fte_roles[${fteIndex}][end_date]" type="text" class="thai-datepicker w-full border p-2 rounded pl-10" placeholder="โปรดใส่วันที่" required>
                    <svg class="w-5 h-5 absolute top-9 left-3 text-gray-500 pointer-events-none"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                    </svg>
                </label>
            </div>
            <div class="flex gap-4 items-end">
                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">FTE</span>
                    <input name="fte_roles[${fteIndex}][fte_value]" type="number" step="0.01" required class="w-full border p-2 rounded" placeholder="โปรดใส่ค่า FTE">
                </label>
                <button type="button" onclick="removeRow('${id}', 'fte')" class="text-red-600 mb-2">✕</button>
            </div>
        </div>
    `);

            fteIndex++;
            reindexFTE();
            initThaiDatepickers();
        }

        let outputIndex = 1;

        function addOutputRow() {
            const id = `output-${outputIndex}`;
            document.getElementById('output-container').insertAdjacentHTML('beforeend', `
            <div id="${id}" class="output-row space-y-2">
                <label class="block w-full">
                    <span class="block text-sm text-gray-700 mb-1">ชื่อผลงานที่ <span class="output-index">${outputIndex + 1}</span></span>
                    <input name="outputs[${outputIndex}][title]" type="text" class="w-full border p-2 rounded">
                </label>
                <div class="grid grid-cols-3 gap-4 items-end">
                    <label class="w-full">
                        <span class="block text-sm text-gray-700 mb-1">ประเภทของผลงาน</span>
                        <input name="outputs[${outputIndex}][type]" type="text" class="w-full border p-2 rounded">
                    </label>
                    <label class="w-full">
                        <span class="block text-sm text-gray-700 mb-1">รายละเอียด / หมายเหตุ / LINK</span>
                        <input name="outputs[${outputIndex}][output]" type="text" class="w-full border p-2 rounded">
                    </label>
                    <div class="flex gap-2 w-full">
                        <label class="w-full">
                            <span class="block text-sm text-gray-700 mb-1">ปี</span>
                            <input name="outputs[${outputIndex}][year]" type="text" class="w-full border p-2 rounded">
                        </label>
                        <button type="button" onclick="removeRow('${id}', 'output')" class="text-red-600 mb-2">✕</button>
                    </div>
                </div>
            </div>
        `);
            outputIndex++;
            reindexOutput();
        }

        let copiIndex = 1;

        function addCopiRow() {
            const id = `copi-${copiIndex}`;
            document.getElementById('copi-container').insertAdjacentHTML('beforeend', `
            <div id="${id}" class="copi-row grid grid-cols-2 gap-4 items-center">
                <label class="w-full">
                    <span class="block text-sm text-gray-700 mb-1">ชื่อ COPI คนที่ <span class="copi-index">${copiIndex + 1}</span></span>
                    <input name="copis[${copiIndex}][name]" type="text" class="w-full border p-2 rounded " placeholder="คำนำหน้า ชื่อ-นามสกุล">
                </label>
                <div class="flex gap-2 w-full">
                    <label class="w-full">
                        <span class="block text-sm text-gray-700 mb-1">สังกัด COPI คนที่ <span class="copi-index">${copiIndex + 1}</span></span>
                        <input name="copis[${copiIndex}][affiliation]" type="text" class="w-full border p-2 rounded" placeholder="สังกัด COPI">
                    </label>
                    <button type="button" onclick="removeRow('${id}', 'copi')" class="text-red-600 mt-6">✕</button>
                </div>
            </div>
        `);
            copiIndex++;
            reindexCopi();
        }

        let coResearchIndex = 1;

        function addCoResearchRow() {
            const id = `coresearch-${coResearchIndex}`;
            document.getElementById('coresearch-container').insertAdjacentHTML('beforeend', `
            <div id="${id}" class="coresearch-row space-y-2 py-4">
                <label class="block w-full">
                    <span class="block text-sm mb-1">ชื่อ Co-Researcher ที่ <span class="coresearch-index">${coResearchIndex + 1}</span></span>
                    <input name="coresearch[${coResearchIndex}][name]" type="text" class="w-full border p-2 rounded"  placeholder="ยศ ชื่อ นามสกุล">
                </label>
                <div class="grid grid-cols-12 gap-4 items-end">
                    <label class="col-span-5">
                        <span class="block text-sm mb-1">สังกัด</span>
                        <input name="coresearch[${coResearchIndex}][affiliation]" type="text" class="w-full border p-2 rounded" placeholder="สังกัด">
                    </label>
                    <label class="col-span-5">
                        <span class="block text-sm mb-1">คนภายนอก/ภายใน</span>
                        <select name="coresearch[${coResearchIndex}][unit_status]" class="w-full border p-2 rounded" required>
                            <option value="" disabled selected>กรุณาเลือก</option>
                            <option value="ภายใน">ภายใน</option>
                            <option value="ภายนอก">ภายนอก</option>
                        </select>
                    </label>
                    <div class="col-span-2 flex justify-end pt-6">
                        <button type="button" onclick="removeRow('${id}', 'coresearch')" class="text-red-600 text-xl">✕</button>
                    </div>
                </div>
            </div>
        `);
            coResearchIndex++;
            reindexCoResearch();
        }

        // ✅ INITIALIZE
        document.addEventListener('DOMContentLoaded', () => {
            initThaiDatepickers();
            setupBudgetInput();

            document.querySelectorAll("select[id$='_status']").forEach(updateStatusColor);
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/maprang/Desktop/SIHPWORK/website/research-system/resources/views/projects/create.blade.php ENDPATH**/ ?>