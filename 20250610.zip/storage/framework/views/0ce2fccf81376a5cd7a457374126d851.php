<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto mt-6">
    <h2 class="text-xl font-bold text-gray-800 mb-4">
        📋 รายละเอียด FTE: <?php echo e($name); ?>

        <?php if($month && $year): ?> – เดือน <?php echo e($month); ?> ปี <?php echo e($year); ?> <?php endif; ?>
    </h2>

    <div class="mb-4">
        <strong>รวม FTE ทั้งหมด:</strong> <?php echo e(number_format($totalFTE, 2)); ?>

    </div>

    <table class="w-full bg-white shadow rounded table-auto text-sm">
        <thead class="bg-gray-100 text-left">
            <tr>
                <th class="px-4 py-2">โครงการ</th>
                <th class="px-4 py-2">บทบาท</th>
                <th class="px-4 py-2">FTE</th>
                <th class="px-4 py-2">เดือน</th>
                <th class="px-4 py-2">ปี</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-t hover:bg-gray-50">
                <td class="px-4 py-2"><?php echo e($row->project->project_name_th ?? '-'); ?></td>
                <td class="px-4 py-2"><?php echo e($row->role_group); ?></td>
                <td class="px-4 py-2"><?php echo e($row->fte_value); ?></td>
                <td class="px-4 py-2"><?php echo e($row->month); ?></td>
                <td class="px-4 py-2"><?php echo e($row->year); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/maprang/Desktop/SYSTEM/research-system/resources/views/fte/detail.blade.php ENDPATH**/ ?>