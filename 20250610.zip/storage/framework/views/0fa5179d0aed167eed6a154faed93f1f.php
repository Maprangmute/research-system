<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto mt-6">
    <h2 class="text-2xl font-bold text-gray-800 mb-4">📊 สรุป FTE รายบุคคล</h2>

    <!-- Filter by year -->
    <form method="GET" action="<?php echo e(route('fte.index')); ?>" class="mb-4 flex gap-2">
        <select name="year" class="border border-gray-300 p-2 rounded">
            <option value="">-- ทุกปี --</option>
            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($year); ?>" <?php echo e(request('year') == $year ? 'selected' : ''); ?>>
                    ปี <?php echo e($year); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded">🔍 ค้นหา</button>
    </form>

    <div class="bg-white shadow rounded overflow-hidden">
        <table class="min-w-full table-auto text-sm">
            <thead class="bg-gray-100 text-left">
                <tr>
                    <th class="px-4 py-2">ชื่อ</th>
                    <th class="px-4 py-2">กลุ่มบทบาท</th>
                    <th class="px-4 py-2 text-right">FTE รวม</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $fteSummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t hover:bg-gray-50">
                    <td class="px-4 py-2">
                        <a href="<?php echo e(route('fte.detail', ['name' => $row->name])); ?>" class="text-blue-600 hover:underline">
                            <?php echo e($row->name); ?>

                        </a>
                    </td>
                    <td class="px-4 py-2"><?php echo e($row->role_group); ?></td>
                    <td class="px-4 py-2 text-right"><?php echo e(number_format($row->total_fte, 2)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="3" class="px-4 py-4 text-center">ไม่พบข้อมูล</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/maprang/Desktop/SIHPWORK/website/research-system/resources/views/fte/index.blade.php ENDPATH**/ ?>