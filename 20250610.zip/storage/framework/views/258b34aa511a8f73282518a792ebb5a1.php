<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto mt-8 p-6 bg-white rounded shadow">
    <h2 class="text-2xl font-bold text-gray-800 mb-6">🔐 จัดการสิทธิ์ผู้ใช้งาน</h2>

    <?php if(session('success')): ?>
        <div class="mb-4 p-3 bg-green-100 text-green-700 rounded">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="w-full table-auto border text-sm">
        <thead class="bg-gray-100 text-left">
            <tr>
                <th class="px-4 py-2 border">ชื่อ</th>
                <th class="px-4 py-2 border">อีเมล</th>
                <th class="px-4 py-2 border">ตำแหน่ง</th>
                <th class="px-4 py-2 border">สิทธิ์</th>
                <th class="px-4 py-2 border">เปลี่ยนสิทธิ์</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="px-4 py-2 border"><?php echo e($user->prefix); ?><?php echo e($user->name); ?></td>
                <td class="px-4 py-2 border"><?php echo e($user->email); ?></td>
                <td class="px-4 py-2 border"><?php echo e($user->position); ?></td>
                <td class="px-4 py-2 border"><?php echo e($user->role); ?></td>
                <td class="px-4 py-2 border">
                    <form action="<?php echo e(route('users.updateRole', $user->id)); ?>" method="POST" class="flex items-center gap-2">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PUT'); ?>
                        <select name="role" class="border p-1 rounded">
                            <option value="user" <?php if($user->role === 'user'): echo 'selected'; endif; ?>>user</option>
                            <option value="admin" <?php if($user->role === 'admin'): echo 'selected'; endif; ?>>admin</option>
                        </select>
                        <button class="bg-blue-600 text-white px-3 py-1 rounded text-xs hover:bg-blue-700">อัปเดต</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/maprang/Desktop/SYSTEM/research-system/resources/views/users/manage.blade.php ENDPATH**/ ?>