<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto mt-10 bg-white shadow p-8 rounded-lg">
    <div class="flex items-center justify-between mb-6">
        <h2 class="text-2xl font-bold text-gray-800">✏️ แก้ไขข้อมูลผู้ใช้งาน</h2>
        <a href="<?php echo e(route('users.index')); ?>" class="text-sm text-purple-600 hover:underline">⬅️ กลับไปยังรายชื่อ</a>
    </div>

    <?php if($errors->any()): ?>
        <div class="bg-red-100 text-red-700 p-3 rounded mb-4">
            <ul class="text-sm list-disc list-inside">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form method="POST" action="<?php echo e(route('users.update', $user->id)); ?>" enctype="multipart/form-data" class="space-y-6">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="flex items-center gap-6">
            <div class="shrink-0">
                <div class="h-24 w-24 rounded-full bg-gray-100 border border-gray-300 flex items-center justify-center overflow-hidden">
                    <img id="avatarPreview" class="h-full w-full object-cover" 
                         src="<?php echo e($user->profile_photo_path ? asset('storage/' . $user->profile_photo_path) : 'https://ui-avatars.com/api/?name=' . urlencode($user->prefix . ' ' . $user->name) . '&background=random&size=128'); ?>"
                         alt="avatar preview">
                </div>
            </div>
            <div class="flex-1">
                <label class="block text-sm text-gray-700 font-medium mb-1">อัปโหลดรูปโปรไฟล์</label>
                <input type="file" name="avatar" id="profile_picture" class="text-sm border rounded p-2 w-full">
                <p class="text-xs text-gray-500 mt-1">สามารถเปลี่ยนได้ตามต้องการ</p>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
                <label class="block text-sm text-gray-700 font-medium">คำนำหน้า</label>
                <select name="prefix" class="w-full border p-2 rounded" required>
                    <?php
                        $prefixes = [
                            'นาย','นางสาว','นาง','คุณ','ดร.','ศ.','รศ.','ผศ.','ศ.ดร.','รศ.ดร.','ผศ.ดร.',
                            'อาจารย์','อาจารย์แพทย์','แพทย์หญิง','นายแพทย์','เภสัชกร','ทันตแพทย์','พยาบาลวิชาชีพ',
                            'ผู้ช่วยศาสตราจารย์','รองศาสตราจารย์','ศาสตราจารย์','อื่นๆ'
                        ];
                    ?>
                    <option value="">เลือกคำนำหน้า</option>
                    <?php $__currentLoopData = $prefixes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prefix): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($prefix); ?>" <?php echo e(old('prefix', $user->prefix) == $prefix ? 'selected' : ''); ?>><?php echo e($prefix); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div>
                <label class="block text-sm text-gray-700 font-medium">ตำแหน่ง</label>
                <input type="text" name="position" value="<?php echo e(old('position', $user->position)); ?>" class="w-full border p-2 rounded">
            </div>

            <div>
                <label class="block text-sm text-gray-700 font-medium">ชื่อ - นามสกุล</label>
                <input type="text" name="name" value="<?php echo e(old('name', $user->name)); ?>" class="w-full border p-2 rounded" required>
            </div>

            <div>
                <label class="block text-sm text-gray-700 font-medium">อีเมล</label>
                <input type="email" name="email" value="<?php echo e(old('email', $user->email)); ?>" class="w-full border p-2 rounded" required>
            </div>

            <div>
                <label class="block text-sm text-gray-700 font-medium">สิทธิ์ผู้ใช้งาน</label>
                <select name="role" class="w-full border p-2 rounded" required>
                    <option value="user" <?php if($user->role === 'user'): echo 'selected'; endif; ?>>user (เข้าถึงข้อมูลของตนเอง)</option>
                    <option value="admin" <?php if($user->role === 'admin'): echo 'selected'; endif; ?>>admin (เข้าถึงทุกข้อมูล)</option>
                    <option value="exp" <?php if($user->role === 'exp'): echo 'selected'; endif; ?>>exp (สิทธิ์พิเศษเฉพาะบางกรณี)</option>
                </select>
            </div>
        </div>

        <div class="pt-4 text-right">
            <button type="submit" class="bg-green-600 text-white px-6 py-2 rounded hover:bg-green-700">
                💾 บันทึกข้อมูล
            </button>
        </div>
    </form>
</div>

<script>
    document.getElementById('profile_picture').addEventListener('change', function (e) {
        const reader = new FileReader();
        reader.onload = function (event) {
            document.getElementById('avatarPreview').src = event.target.result;
        }
        if (e.target.files[0]) {
            reader.readAsDataURL(e.target.files[0]);
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/maprang/Desktop/SYSTEM/research-system/resources/views/users/edit.blade.php ENDPATH**/ ?>