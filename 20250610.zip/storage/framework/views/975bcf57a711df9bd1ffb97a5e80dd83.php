<?php $__env->startSection('content'); ?>
<div class="max-w-6xl mx-auto mt-8 bg-white shadow p-6 rounded">
    <h2 class="text-2xl font-bold text-gray-800 mb-4">👥 รายชื่อผู้ใช้งาน</h2>

    <table class="w-full table-auto border text-sm">
        <thead class="bg-gray-100 text-left">
            <tr>
                <th class="px-4 py-2 border">ชื่อ</th>
                <th class="px-4 py-2 border">อีเมล</th>
                <th class="px-4 py-2 border">ตำแหน่ง</th>
                <th class="px-4 py-2 border">สิทธิ์</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="hover:bg-gray-50">
                <td class="px-4 py-2 border"><?php echo e($user->prefix); ?><?php echo e($user->name); ?></td>
                <td class="px-4 py-2 border"><?php echo e($user->email); ?></td>
                <td class="px-4 py-2 border"><?php echo e($user->position); ?></td>
                <td class="px-4 py-2 border"><?php echo e($user->role); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/maprang/Desktop/SIHPWORK/website/research-system/resources/views/users/index.blade.php ENDPATH**/ ?>