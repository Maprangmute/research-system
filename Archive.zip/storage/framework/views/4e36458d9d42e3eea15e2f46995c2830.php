<?php $__env->startSection('content'); ?>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/animate.css@4.1.1/animate.min.css"/>


<?php if(session('error')): ?>
<script>
    Swal.fire({
        toast: true,
        position: 'bottom-end',
        icon: 'error',
        title: '<?php echo e(session('error')); ?>',
        showConfirmButton: false,
        timer: 7000,
        timerProgressBar: true,
        showClass: {
            popup: 'animate__animated animate__fadeInUp'
        },
        hideClass: {
            popup: 'animate__animated animate__fadeOutDown'
        }
    });
</script>
<?php endif; ?>




<div class="max-w-7xl mx-auto mt-6">
    <h2 class="text-2xl font-bold text-gray-800 mb-4">📊 รายการโครงการวิจัย</h2>

    <!-- Filter Form -->
    <form method="GET" action="<?php echo e(route('projects.index')); ?>" class="bg-white p-4 rounded shadow mb-6 grid grid-cols-1 md:grid-cols-4 gap-4">
        <input type="text" name="search" placeholder="ค้นหาชื่อโครงการ" value="<?php echo e(request('search')); ?>" class="border p-2 rounded">
        <input type="text" name="type" placeholder="ประเภทโครงการ" value="<?php echo e(request('type')); ?>" class="border p-2 rounded">
        <input type="text" name="year" placeholder="ปี (พ.ศ.)" value="<?php echo e(request('year')); ?>" class="border p-2 rounded">
        <button type="submit" class="bg-indigo-600 text-white px-4 py-2 rounded">🔍 ค้นหา</button>
    </form>

    <!-- Project List -->
    <div class="bg-white shadow overflow-hidden sm:rounded-lg">
        <table class="min-w-full table-auto">
            <thead class="bg-gray-100 text-left">
                <tr>
                    <th class="px-4 py-2">#</th>
                    <th class="px-4 py-2">PROJECT ID</th>
                    <th class="px-4 py-2">ชื่อโครงการ</th>
                    <th class="px-4 py-2">ประเภท</th>
                    <th class="px-4 py-2">Theme</th>
                    <th class="px-4 py-2">ปี</th>
                    <th class="px-4 py-2">จัดการ</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="border-t hover:bg-gray-50">
                    <td class="px-4 py-2"><?php echo e($project->id); ?></td>
                    <td class="px-4 py-2"><?php echo e($project->project_code); ?></td>
                
                    
                    <td class="px-4 py-2">
                        <a href="<?php echo e(route('projects.show', $project->id)); ?>" class="text-blue-600 hover:underline">
                            <?php echo e($project->project_name_th); ?>

                        </a>
                    </td>
                
                    <td class="px-4 py-2"><?php echo e($project->project_type); ?></td>
                    <td class="px-4 py-2"><?php echo e($project->theme); ?></td>
                    <td class="px-4 py-2"><?php echo e($project->start_year); ?></td>
                
                    
                    <td class="px-4 py-2 space-x-2">
                        <a href="<?php echo e(route('projects.edit', $project->id)); ?>" class="text-yellow-600 hover:underline">✏️ แก้ไข</a>
                        
                        <form action="<?php echo e(route('projects.destroy', $project->id)); ?>" method="POST" class="inline-block" onsubmit="return confirm('คุณแน่ใจว่าต้องการลบโครงการนี้หรือไม่?')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="text-red-600 hover:underline">🗑️ ลบ</button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr><td colspan="8" class="text-center py-4">ไม่มีข้อมูล</td></tr>
                <?php endif; ?>
                
            </tbody>
        </table>
    </div>

    <div class="mt-4"><?php echo e($projects->links()); ?></div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/maprang/Desktop/SIHPWORK/website/research-system/resources/views/projects/index.blade.php ENDPATH**/ ?>